QUIET HIVE - RimWorld 1.6

A covert parasite/hive infection prototype.

CURRENT BEHAVIOR
- Infected humanlike pawns keep their normal faction and normal daily behavior.
- They periodically look for uninfected, non-hostile humanlike targets.
- They strongly prefer sleeping, downed, indoor, isolated, and uncrowded victims.
- Uninfected conscious pawns with line of sight count as witnesses.
- Hive members do not expose one another.
- If a witness is present, the host normally refuses to begin an attempt.
- If somebody appears before the final infection action, the host aborts.
- Being caught raises internal suspicion and makes the host lie low for longer.
- As the local hive grows, very low-suspicion hosts become a little bolder.
- Infection does not turn the pawn into a hostile zombie.

STARTING AN INFECTION
QuietHive_Infection is marked scenarioCanAdd, so for testing you can make a custom scenario that starts one pawn with the Quiet Hive infection.

INSTALL
The playable build needs Assemblies/QuietHive.dll. Put the completed QuietHive folder in RimWorld/Mods and enable "Quiet Hive" in the mod list.

SOURCE
Source/QuietHive contains the C# project targeting RimWorld 1.6 reference assemblies.
